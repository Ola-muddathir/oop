import java.util.ArrayList;

public class Cart {
    private ArrayList<CartItem> items;

    public Cart() {
        items = new ArrayList<>();
    }

    public void addItem(CartItem item) {
        items.add(item);
    }

    public void removeItem(String dishName) {
        items.removeIf(item -> item.getDishName().equals(dishName));
    }

    public double calculateTotal() {
        double total = 0;
        for (CartItem item : items) {
            total += item.getSubtotal();
        }
        return total;
    }

    public void clearCart() {
        items.clear();
    }

    public void showCart() {
        if (items.isEmpty()) {
            System.out.println("The cart is empty");
        } else {
            System.out.println("Items in your cart");
            for (CartItem item : items) {
                System.out.println("Dish: " + item.getDishName() + ", Quantity: " + item.getQuantity() + ", Subtotal" + item.getSubtotal());
            }
        }
    }

    public ArrayList<CartItem> getItems() {
        return items;
    }
}

