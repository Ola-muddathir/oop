public class CartItem {
    private Dish dish;
    private double price;
    private int quantity;
    public CartItem(Dish dish,  double price,  int quantity) {
        this.dish = dish;
        this.price = price;
        this.quantity = quantity;
    }

    public double getSubtotal() {
        return dish.getPrice() * quantity;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getDishPrice() {
        return price;
    }

    public String  getDishName() {
        return dish.getName();
    }
}

