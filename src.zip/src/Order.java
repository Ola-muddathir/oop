import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

enum OrderStatus {
        IN_PROGRESS,
        PAID,
        PREPARING,
        DELIVERED
}

class Order {
        private static int orderCounter = 0;
        private int orderId;
        private ArrayList<CartItem> items;
        private OrderStatus status;
        private String deliveryAddress;
        private double totalAmount;

        // Constructor
        public Order() {
                this.orderId = ++orderCounter;
                this.items = new ArrayList<>();
                this.status = OrderStatus.IN_PROGRESS;
                this.totalAmount = 0.0;
        }

        // Method to place the order
        public void placeOrder(ArrayList<CartItem> items, String deliveryAddress) {
                this.items = items;
                this.deliveryAddress = deliveryAddress;
                calculateTotalAmount();
        }

        // Method to update the status of the order
        public void updateStatus(OrderStatus newStatus) {
                this.status = newStatus;
        }

        // Method to view the order details
        public void viewOrderDetails() {
                System.out.println("Order ID: " + orderId);
                System.out.println("Status: " + status);
                System.out.println("Delivery Address: " + deliveryAddress);
                System.out.println("Items in Order:");
                for (CartItem item : items) {
                        System.out.println("- " + item.getDishName() + ": $" + item.getDishPrice());
                }
                System.out.println("Total Amount: $" + totalAmount);
        }

        // Method to calculate total amount
        public double calculateTotalAmount() {
                totalAmount = 0.0;
                for (CartItem item : items) {
                        totalAmount += item.getSubtotal();
                }
                return totalAmount;
        }

        // Method to process payment
        public boolean processPayment() {
                Scanner scanner = new Scanner(System.in);

                // Ask user for payment method
                System.out.println("Choose a payment method:");
                System.out.println("1. Credit/Debit Card");
                System.out.println("2. Digital Wallet");
                int choice = scanner.nextInt();

                Payment.PaymentMethod selectedMethod;
                if (choice == 1) {
                        selectedMethod = Payment.PaymentMethod.CREDIT_CARD;
                } else if (choice == 2) {
                        selectedMethod = Payment.PaymentMethod.DIGITAL_WALLET;
                } else {
                        System.out.println("Invalid choice. Payment failed.");
                        return false;
                }

                // Create a Payment object and process the payment
                Payment payment = new Payment(selectedMethod, null, "Pending");
                boolean success = payment.processPayment(totalAmount);

                // Update order status based on payment outcome
                if (success) {
                        updateStatus(OrderStatus.PAID);
                        scheduleOrderStatusChange(); // Start status change process
                } else {
                        updateStatus(OrderStatus.PAID); // or any other status for failure
                }

                return success;
        }

        // Method to schedule automatic status changes after payment
        public void scheduleOrderStatusChange() {
                ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

                // Change to "PREPARING" after 5 seconds
                scheduler.schedule(() -> {
                        updateStatus(OrderStatus.PREPARING);
                        // Change to "DELIVERED" after 5 seconds from PREPARING
                        scheduler.schedule(() -> {
                                updateStatus(OrderStatus.DELIVERED);
                        }, 5, TimeUnit.SECONDS);
                }, 5, TimeUnit.SECONDS); // Delay the first status change by 5 seconds
        }

        // Getter for totalAmount
        public double getTotalAmount() {
                return totalAmount;
        }
}