import java.util.ArrayList;
import java.util.List;

class Dish {
    private String name;
    private String description;
    private double price;
    private String category;

    public Dish(String name, String description, double price, String category) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public String getDetails() {
        return "Name: " + name +
                "\nDescription: " + description +
                "\nPrice: $" + String.format("%.2f", price) +
                "\nCategory: " + category;
    }

    public double getPrice() {
        return price;
    }

    public void updatePrice(double newPrice) {
        this.price = newPrice;
    }
}
